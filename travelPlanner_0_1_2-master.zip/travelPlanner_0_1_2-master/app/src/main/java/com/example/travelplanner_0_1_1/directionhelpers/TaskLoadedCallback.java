package com.example.travelplanner_0_1_1.directionhelpers;

public interface TaskLoadedCallback {

    void onTaskDone(String key, Object... values);
}
